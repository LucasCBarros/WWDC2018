
//#-hidden-code
loadLiveView()
//#-end-hidden-code

/*:#localized(key: "FirstProseBlock")
 
 **print("Hello! My name is Lucas!")**
 
 I'm a technology enthusiast and I would like to share a part of my story 🤓
 
 Back in 2009 I voluntered in a public school nearby my highSchool, I gave math class to kids from age 8 to 14 and i've realized they had such difficulty learning, so I used beans, bottle caps and other simple resources to try explaining the math operations. Back then I felt the need for better resources.
 
 So in 2011, when I went to college, I chose Licenciature in Physics in the University of Campinas (UNICAMP) so I could learn new methods of teaching. With time I began to notice that my colegues also felt a lot of difficulty teaching in public schools where they had limited resources. Our licenciature teachers in the university always incentivated us to find solutions in tecnology since one simple iPad could hold so much potential as different methods, materials and even be adaptable to each students learning speed.
 
 In 2012, during my graduation I started a technical information technology course to obtain more knowledge on how to apply the use of tecnologies in the classroom and that's when I fell in love with programming and how it opens a world of possibilities like using different resources, offering knowledge to everyone or even reinventing old methods like the Kumon Method to teach math.
 
While I was in technical school I met a 16 year old boy that told me that his dream was to study at UNICAMP so I helped him prepare for the exams but I saw he had trouble solving simple equations with divisions and multiplications. We made a lot of progress but unfortunately when the exams came he still wasn't ready enought. I felt that I failed him, but that motivated me to keep learning and growing.
 
 After I graduated in my technical information technology course in 2014, I felt that I could help my colegues by developing new tools to help them improve their teaching experience, so I changed to Applied and Computional Mathematics where I came in contact with more tecnological aproaches since my gratuation uses computers to teach how to solve complex mathematical problems. I thought could apply the same principle for basic math, so I kept taking mathematical licenciature classes to observe tradicional methods that worked and could be combined with tecnology to improve students learning experience.
 
 In 2017 I entered the Apple Developer Academy at Campinas and it chanced even more my perpective of how to help people through mobile aplications that are so in our daily lifes. I also became aware of Apples other education iniciatives like ConnectedED, iPad Pilot Program and Apple Representetive, and how these programs have such positive impact the comunity and it really thrills me to think I may also have the oportunity to help people around me through programs like that.
 
 Now I see that at the time when I tried to help that boy, if I had used better resources he could have obtained better results. With that in mind, I made this playground so to help not only him but so many others that have the same difficulties with math. This playground is about making people learn by playing a simple game, because it's not a matter of making something beautiful, but about having students reach their goals.
 
[So let's play!](@next) 🎲 🎮 🕹️ 👾
 
 
 */

//#-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, playGame())


//#-end-hidden-code

